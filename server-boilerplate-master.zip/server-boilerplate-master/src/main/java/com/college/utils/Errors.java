package com.college.utils;

public class Errors {



}
