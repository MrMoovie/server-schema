package com.college.utils;


public class Constants {


}
