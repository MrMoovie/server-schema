package com.college.utils;

public class ApiUtils {

}
